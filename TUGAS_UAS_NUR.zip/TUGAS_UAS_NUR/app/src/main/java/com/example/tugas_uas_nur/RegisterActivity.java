package com.example.tugas_uas_nur;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tugas_uas_nur.helper.Database;
import com.example.tugas_uas_nur.model.User;

public class RegisterActivity extends AppCompatActivity {
    Button registerAction;
    EditText nameRegister, emailRegister, passwordRegister;
    Database db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        db = new Database(this);
        nameRegister = findViewById(R.id.nameRegister);
        emailRegister = findViewById(R.id.emailRegister);
        passwordRegister = findViewById(R.id.passwordRegister);
        registerAction = findViewById(R.id.registerAction);
        registerAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user = new User(null, nameRegister.getText().toString(), emailRegister.getText().toString(), passwordRegister.getText().toString());
                db.register(user);
                Toast.makeText(getApplicationContext(), "Register Berhasil", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void onRegisterClick (View view){
        startActivity(new Intent(this,MainActivity.class));

    }
}